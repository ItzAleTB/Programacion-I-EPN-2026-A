
package fis.po.ccu2repasobim1;

public class Estudiante extends Persona {
    private String codigo;
    private String carrera;

    public Estudiante(String cedula, String nombre, String email, String codigo, String carrera) {
        super(cedula, nombre, email);
        this.codigo = codigo;
        this.carrera = carrera;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getCarrera() {
        return carrera;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "codigo=" + codigo + ", carrera=" + carrera + '}';
    }

   
    
    
}
