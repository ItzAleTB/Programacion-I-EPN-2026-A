
package fis.po.ccu2repasobim1;

import java.util.Objects;

public class Persona {
        private String cedula;
        private String nombre;
        private String email;

        public Persona(String cedula, String nombre, String email) {
            if(cedula == null || !cedula.matches("\\d{10}")){
                throw new IllegalArgumentException("La cédula debe tener exactamente 10 dígitos.");
            }
            if(nombre == null || nombre.isBlank()){
                throw new IllegalArgumentException("El nombre no puede estar vacío.");
            }
            
            this.cedula = cedula;
            this.nombre = nombre;
            this.email = email;
        }

        public String getCedula() {
            return cedula;
        }

        public String getNombre() {
            return nombre;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        private String validarEmail(String email){
            if(email == null || !email.contains("@")){
                throw new IllegalArgumentException("El correo debe contener '@'.");
            }
            return email;
        }

    @Override
    public String toString() {
        return "Persona{" + "cedula=" + cedula + ", nombre=" + nombre + ", email=" + email + '}';
    }

        

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if(!(o instanceof Persona persona)) return false;
            return Objects.equals(cedula, persona.cedula);
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(cedula);
        }
        
}
