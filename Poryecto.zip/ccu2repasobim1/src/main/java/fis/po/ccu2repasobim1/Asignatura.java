/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fis.po.ccu2repasobim1;

/**
 *
 * @author P5E003-O
 */
public class Asignatura {
    
}
