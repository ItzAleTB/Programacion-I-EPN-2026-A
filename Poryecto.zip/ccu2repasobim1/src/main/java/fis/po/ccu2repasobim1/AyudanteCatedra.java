
package fis.po.ccu2repasobim1;

public class AyudanteCatedra extends Estudiante{
    public static double VALOR_HORA = 6.00;
    public static int MAX_HORAS_SEMANA = 20;
    private int horasSemanales;
    private Asignatura asignatura;

    public AyudanteCatedra(String cedula, String nombre, String email, String codigo, String carrera, Asignatura asignatura, int horasSemanales) {
        super(cedula, nombre, email, codigo, carrera);
        this.asignatura = asignatura;
        this.horasSemanales = horasSemanales;
    }

    public int getHorasSemanales() {
        return horasSemanales;
    }

    public Asignatura getAsignatura() {
        return asignatura;
    }
    
    public double calcularPagoMensual(){
        return horasSemanales * VALOR_HORA * 4;
    }

    @Override
    public String toString() {
        return "AyudanteCatedra{" + ", asignatura=" + (asignatura != null? asignatura.getNombre(): "N/A") + "horasSemanales=" + horasSemanales + ", pagoMensual=" + calcularPagoMensual() + '}';
    }
    
    
}
