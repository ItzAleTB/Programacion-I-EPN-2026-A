
package fis.po.ccu2repasobim1;
import java.util.ArrayList;

public class Paralelo {
    
    private String codigo;
    private int cupo;
    private Asignatura asignatura;
    private Profesor profesor;
    private ArrayList<Estudiante> inscritos;

    public Paralelo(String codigo, int cupo, Asignatura asignatura, Profesor profesor) {
        this.codigo = codigo;
        this.cupo = cupo;
        this.asignatura = asignatura;
        this.profesor = profesor;
        this.inscritos = new ArrayList<>();
    }

    public boolean hayCupo() {
        return inscritos.size() < cupo;
    }

    public String inscribir(Estudiante e) {
        if (e == null) {
            return "Estudiante inválido.";
        }
        if (inscritos.contains(e)) {
            return "El estudiante ya está inscrito en este paralelo.";
        }
        if (!hayCupo()) {
            return "No hay cupo disponible en el paralelo.";
        }
        inscritos.add(e);
        return "Estudiante inscrito correctamente.";
    }

    public boolean retirar(Estudiante e) {
        return inscritos.remove(e);
    }

    public void imprimir() {
        System.out.println("Paralelo: " + codigo + " | Asignatura: " + asignatura.getNombre());
        System.out.println("Profesor: " + profesor.getNombre());
        System.out.println("Inscritos (" + inscritos.size() + "/" + cupo + "):");
        for (Estudiante e : inscritos) {
            System.out.println(" - " + e.getNombre() + " (" + e.getCodigo() + ")");
        }
    }
}
