
package fis.po.ccu2repasobim1;

public class Profesor extends Persona{
    private String titulo;
    private String departamento;

    public Profesor(String cedula,String nombre, String email, String titulo, String departamento) {
        super(cedula, nombre, email);
        this.titulo = titulo;
        this.departamento = departamento;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDepartamento() {
        return departamento;
    }

    @Override
    public String toString() {
        return "Profesor{" + "titulo=" + titulo + ", departamento=" + departamento + '}';
    }
    
    
    
}
