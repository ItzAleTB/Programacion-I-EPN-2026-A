package fis.po.ccu2repasobim1;
public class Ccu2repasobim1 {

    public static void main(String[] args) {

// Creación del docente y paralelo con cupo 3

Profesor prof = new Profesor("1711111111", "Carla Andrade", "carla.andrade@epn.edu.ec",

"PhD", "Informática y Ciencias de la Computación");

Paralelo paralelo = new Paralelo("GR1", "Programación Orientada a Objetos", prof, 3);



// Creación de estudiantes válidos

Estudiante est1 = new Estudiante("1712345678", "Ana Torres", "ana.torres@epn.edu.ec",

"Software", "202310001");

AyudanteCatedra ayudante = new AyudanteCatedra("1723456789", "Sofía Ruiz", "sofia.ruiz@epn.edu.ec",

"Software", "202110007", 10,

"Programación Orientada a Objetos");



// Inscripciones válidas

System.out.println(paralelo.inscribir(est1));

System.out.println(paralelo.inscribir(ayudante));

System.out.println("Pago mensual ayudante: $" + ayudante.calcularPagoMensual());



// Prueba 1: Nuevo objeto Estudiante con la misma cédula del primero (debe rechazarse)

Estudiante estDuplicado = new Estudiante("1712345678", "Ana Torres Clon", "clon@epn.edu.ec",

"Software", "202310001");

System.out.println(paralelo.inscribir(estDuplicado));



// Prueba 2: Estudiante con la cédula de la profesora (debe rechazarse)

Estudiante estProfe = new Estudiante("1711111111", "Carla Andrade", "carla@epn.edu.ec",

"Software", "202099999");

System.out.println(paralelo.inscribir(estProfe));



// Mostrar resumen con formatos toString()

paralelo.mostrarListado();



System.out.println("\n=== Pruebas de validación de datos ===");



// Prueba 3: Cédula de 5 dígitos

try {

new Estudiante("12345", "Luis Pérez", "luis@epn.edu.ec", "Computación", "202310002");

} catch (IllegalArgumentException ex) {

System.out.println("Prueba cédula inválida -> " + ex.getMessage());

}



// Prueba 4: Correo sin @

try {

new Estudiante("1798765432", "María López", "marialopez.epn.edu.ec", "Computación", "202310003");

} catch (IllegalArgumentException ex) {

System.out.println("Prueba correo inválido -> " + ex.getMessage());

}



// Prueba 5: Ayudante con 30 horas

try {

new AyudanteCatedra("1755555555", "Carlos Mena", "carlos@epn.edu.ec", "Software",

"202210005", 30, "Estructuras de Datos");

} catch (IllegalArgumentException ex) {

System.out.println("Prueba horas inválidas -> " + ex.getMessage());

}

}
    
}
